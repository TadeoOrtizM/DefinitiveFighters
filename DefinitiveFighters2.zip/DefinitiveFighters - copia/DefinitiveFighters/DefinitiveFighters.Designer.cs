﻿namespace DefinitiveFighters
{
    partial class DefinitiveFighters
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Escenario = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Escenario)).BeginInit();
            this.SuspendLayout();
            // 
            // Escenario
            // 
            this.Escenario.BackColor = System.Drawing.Color.White;
            this.Escenario.Location = new System.Drawing.Point(10, 12);
            this.Escenario.Name = "Escenario";
            this.Escenario.Size = new System.Drawing.Size(1280, 720);
            this.Escenario.TabIndex = 0;
            this.Escenario.TabStop = false;
            this.Escenario.Click += new System.EventHandler(this.Escenario_Click);
            this.Escenario.Paint += new System.Windows.Forms.PaintEventHandler(this.Escenario_Paint);
            // 
            // DefinitiveFighters
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1302, 783);
            this.Controls.Add(this.Escenario);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "DefinitiveFighters";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.DefinitiveFighters_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DefinitiveFighters_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DefinitiveFighters_KeyPress);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.DefinitiveFighters_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.Escenario)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox Escenario;
    }
}

