﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DefinitiveFighters
{
    class Jugador
    {
        public double distancia;

        public double ancho;
        public double alto;

        //public double salud;
        //public double desplazamiento;
        //public bool estado;

        public double x;
        public double y;
        
        public bool movimientoarriba = false;
        public bool movimientoabajo = false;

        Keys teclaarriba;
        Keys teclaabajo;

        public Image i;


        public Jugador(double distancia, double ancho, double alto, Image i, double x, double y, Keys teclaarriba, Keys teclaabajo)
        {
            this.teclaarriba = teclaarriba;
            this.teclaabajo = teclaabajo;
            this.x = x;
            this.y = y;
            this.distancia = distancia;

            this.ancho = ancho;
            this.alto = alto;

            this.i = i;
        }

        public void Mover(double desplazamiento)
        {
            if (movimientoarriba && movimientoabajo)
            {
                return;
            }
            else if (movimientoarriba)
            {
                if (y - desplazamiento >= 0)
                {
                    y -= desplazamiento;
                }
                else
                {
                    y = 0;
                }
            }
            else if (movimientoabajo)
            {
                if ((y + distancia + desplazamiento) <= alto)
                {
                    y += desplazamiento;
                }
                else
                {
                    y = alto - distancia;
                }
            }
        }
        public void ActualizarTecla(Keys key, bool down)
        {
            if (key == teclaarriba)
            {
                movimientoarriba = down;
            }
            else if (key == teclaabajo)
            {
                movimientoabajo = down;
            }
        }
        public void Dibujar(PaintEventArgs e)
        {
            { 
                e.Graphics.DrawImage(i, (int)(x), (int)(y), (int)(distancia), (int)(distancia));
            }
        }
    }
}


