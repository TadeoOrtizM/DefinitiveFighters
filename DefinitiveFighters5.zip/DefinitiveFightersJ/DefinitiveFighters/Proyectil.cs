﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DefinitiveFighters
{
    class Proyectil
    {
        public double velocidad;
        public double daño;
        public Image i;
        public double sentido;
        public double tamaño;

        public double x;
        public double y;

        public double ancho;
        public double alto;

        public Keys tecladisparo;
        public Keys teclaarriba;
        public Keys teclaabajo;

        public bool movimientoarriba;
        public bool movimientoabajo;
    }
}
