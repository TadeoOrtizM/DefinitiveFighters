﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DefinitiveFighters
{
    class RafagaDeEnergia : Proyectil
    {
        private bool disparorafaga;
        public double distancia;
        public RafagaDeEnergia(double distancia, double ancho, double alto, double tamaño, double velocidad, double sentido, double daño, Image i, double x, double y, Keys teclaarriba, Keys teclaabajo, Keys tecladisparo)
        {
            this.velocidad = velocidad;
            this.tamaño = tamaño;
            this.sentido = sentido;
            this.daño = daño;
            this.i = i;
            this.x = x;
            this.y = y;
            this.ancho = ancho;
            this.alto = alto;
            this.teclaabajo = teclaabajo;
            this.teclaarriba = teclaarriba;
            this.tecladisparo = tecladisparo;
            this.distancia = distancia;
        }
        public void Desplazar(double desplazamiento, double limite)
        {
            if (movimientoarriba && movimientoabajo)
            {
                return;
            }
            else if (disparorafaga && movimientoarriba)
            {
                if (y - desplazamiento >= 0)
                {
                    if (Math.Abs(tamaño) >= ancho)
                    {
                        tamaño = ancho;
                        y -= desplazamiento;
                    }
                    else
                    {
                        tamaño += velocidad;
                        y -= desplazamiento;
                    }
                }
                else
                {
                    if (Math.Abs(tamaño) >= ancho)
                    {
                        tamaño = ancho;
                        y = 0;
                    }
                    else
                    {
                        tamaño += velocidad;
                        y = 0;
                    }

                }
            }
            else if (disparorafaga && movimientoabajo)
            {
                if ((y + desplazamiento) <= alto - distancia)
                {
                    if (Math.Abs(tamaño) >= ancho)
                    {
                        tamaño = ancho;
                        y += desplazamiento;
                    }
                    else
                    {
                        tamaño += velocidad;
                        y += desplazamiento;
                    } 
                }
                else
                {
                    if (Math.Abs(tamaño) >= ancho)
                    {
                        tamaño = ancho;
                        y = alto - distancia;
                    }
                    else
                    {
                        tamaño += velocidad;
                        y = alto - distancia;
                    }
                }
            }
            else if (movimientoarriba)
            {
                if (y - desplazamiento >= 0)
                {
                    y -= desplazamiento;
                }
                else
                {
                    y = 0;
                }
            }
            else if (movimientoabajo)
            {
                if ((y + desplazamiento) <= alto - distancia)
                {
                    y += desplazamiento;
                }
                else
                {
                    y = alto - distancia;
                }
            }
            else if (disparorafaga)
            {
                if (Math.Abs(tamaño) >= ancho)
                {
                    tamaño = ancho;
                }
                else
                {
                    tamaño += velocidad;
                }

            }
        }

            public void ActualizarTecla(Keys key, bool down)
        {
            if (key == teclaarriba)
            {
                movimientoarriba = down;
            }
            else if (key == teclaabajo)
            {
                movimientoabajo = down;
            }
        }
        public void ActualizarTeclaD(Keys key, bool down)
        {
            if (key == tecladisparo)
            {
                disparorafaga = down;
            }
        }

        public void Dibujar(PaintEventArgs e, double altura)
        {
            if (disparorafaga)
            {
                e.Graphics.DrawImage(i, (int)(x), (int)(y), (int)(sentido * tamaño), (int)(altura));
            }
        }
    }
}
