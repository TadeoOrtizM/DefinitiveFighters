﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DefinitiveFighters
{
    class BolasDeEnergia
    {
        private BolaDeEnergia[] bolas;

        public int contadordebolas = 1;
        private Keys tecladisparo;
        public double x;
        private bool disparobola=false;


        public void AumentarContador()
        {
            if (disparobola)
            {
                Console.WriteLine("Contador Aumentado");
                contadordebolas++;
            }
        }
        public void ActualizarTeclaContador(Keys key, bool down)
        {
            if (key == tecladisparo)
            {
                Console.WriteLine("Cambio de estado true");
                disparobola = down;
            }
            disparobola = false;
            Console.WriteLine("Cambio de estado false");
        }
        public BolasDeEnergia(double ancho, double alto, double tamaño, double velocidad, double sentido, double daño, Image i, double x, double y, Keys teclaarriba, Keys teclaabajo, Keys tecladisparo)
        {
            bolas = new BolaDeEnergia[contadordebolas];
            this.tecladisparo = tecladisparo;
            this.x = x;

            for (int c = 0; c < contadordebolas; c++)
                bolas[c] = new BolaDeEnergia(ancho, alto, tamaño, velocidad, sentido, daño, i, x, y, teclaarriba, teclaabajo, tecladisparo);
            Console.WriteLine("Vector");
        }
        
        
        public void Desplazar(double desplazamiento, double limite, bool condicion)
        {
            for (int c = 0; c < contadordebolas; c++)
                bolas[c].Desplazar(desplazamiento,limite,condicion);
        }
        public void ActualizarTecla(Keys key, bool down)
        {
            for (int c = 0; c < contadordebolas; c++)
                bolas[c].ActualizarTecla(key, down);
        }
        public void ActualizarTeclaD(Keys key, bool down)
        {
            for (int c = 0; c < contadordebolas; c++)
                bolas[c].ActualizarTeclaD(key, down);
        }
        public void Dibujar(PaintEventArgs e)
        {
            for (int c = 0; c < bolas.Length; c++)
               bolas[c].Dibujar(e);
        }
    }
}
