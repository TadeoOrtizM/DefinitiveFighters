﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DefinitiveFighters
{
    class BolaDeEnergia : Proyectil
    {
        private bool disparobola;
        private double px;
        private double py;
        private double poder;
        public double dañoneto = 0;
        public double contadordaño = 1;

        public BolaDeEnergia(double ancho, double alto, double tamaño, double velocidad, double sentido, double daño, Image i, double x, double y, Keys teclaarriba, Keys teclaabajo, Keys tecladisparo)
        {
            this.velocidad = velocidad;
            this.tamaño = tamaño;
            this.sentido = sentido;
            this.daño = daño;
            this.i = i;
            this.x = x;
            this.y = y;
            this.ancho = ancho;
            this.alto = alto;
            this.teclaabajo = teclaabajo;
            this.teclaarriba = teclaarriba;
            this.tecladisparo = tecladisparo;
        }
        public void Desplazar(double desplazamiento, double limite, bool condicion)
        {
            if (disparobola && movimientoabajo && movimientoarriba)
            {
                if (condicion)
                {
                    x = (limite + tamaño * sentido);
                    disparobola = false;
                }
                else
                {
                    x += (velocidad * sentido);
                }
                return;
            }
            else if (disparobola && movimientoarriba)
            {
                if (condicion)
                {
                    x = (limite + tamaño * sentido);
                    disparobola = false;
                }
                else
                {
                    x += (velocidad * sentido);
                }
                return;
            }
            else if (disparobola && movimientoabajo)
            {
                if (condicion)
                {
                    x = (limite + tamaño * sentido);
                    disparobola = false;
                }
                else
                {
                    x += (velocidad * sentido);
                }
                return;
            }

            else if (disparobola)
            {
                if (condicion)
                {
                    x = (limite + tamaño * sentido);
                    disparobola = false;
                }
                else
                {
                    x += (velocidad * sentido);
                }
                return;
            }
            else if (movimientoarriba && movimientoabajo)
            {
                return;
            }
            else if (movimientoarriba)
            {
                if (y - desplazamiento >= tamaño / 2)
                {
                    y -= desplazamiento;
                }
                else
                {
                    y = tamaño / 2;
                }
            }
            else if (movimientoabajo)
            {
                if ((y + desplazamiento) <= alto - (tamaño + tamaño / 2))
                {
                    y += desplazamiento;
                }
                else
                {
                    y = alto - (tamaño + tamaño / 2);
                }
            }
        }
        public void ActualizarTecla(Keys key, bool down)
        {
            if (key == teclaarriba)
            {
                movimientoarriba = down;
            }
            else if (key == teclaabajo)
            {
                movimientoabajo = down;
            }
        }
        public void ActualizarTeclaD(Keys key, bool down, double xinicial, double yinicial)
        {  
            if (key == tecladisparo)
            {
                x = xinicial;
                y = yinicial;
                disparobola = down;
            }
        }

        public void Dibujar(PaintEventArgs e)
        {
            if (disparobola)
            {
                e.Graphics.DrawImage(i, (int)(x), (int)(y), (int)(tamaño), (int)(tamaño));
            }
        }
        public void InflingirDaño()
        {
            contadordaño = 1;
            do { contadordaño--;  dañoneto += daño;} while (contadordaño > 0);
        }
        public void GetCoordenadasJugador(double px, double py)
        {
            this.px = px;
            this.py = py;
        }
        public void GetPoder(double poder)
        {
            this.poder = poder;
        }
        public Rectangle GetRectangle()
        {
            return new Rectangle((int)(x), (int)(y), (int)(tamaño), (int)(tamaño));
        }
    }
}
