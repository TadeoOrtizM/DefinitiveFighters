﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DefinitiveFighters
{
    class RafagaDeEnergia : Proyectil
    {
        private bool disparorafaga;
        public double distancia;
        private double rx;
        private double ry;
        public double poder;
        public double dañoneto = 0;
        private double altura;
        private double tamañocambiado;

        public RafagaDeEnergia(double distancia, double ancho, double alto, double tamaño, double velocidad, double sentido, double daño, Image i, double x, double y, Keys teclaarriba, Keys teclaabajo, Keys tecladisparo)
        {
            this.velocidad = velocidad;
            this.tamaño = tamaño;
            this.sentido = sentido;
            this.daño = daño;
            this.i = i;
            this.x = x;
            this.y = y;
            this.ancho = ancho;
            this.alto = alto;
            this.teclaabajo = teclaabajo;
            this.teclaarriba = teclaarriba;
            this.tecladisparo = tecladisparo;
            this.distancia = distancia;
        }
        public void Desplazar(double desplazamiento, double contadorpoder)
        {
            double contador = 10000; 

            if (movimientoabajo && movimientoarriba && disparorafaga)
            {
                if (poder > 0)
                {
                    if (Math.Abs(tamaño) >= ancho)
                    {
                        poder -= 50;
                        tamaño = ancho;
                        do { contador -= 1; } while (contador > 0);
                        disparorafaga = false;
                        tamaño = distancia;
                    }
                    else
                    {
                        tamaño += velocidad;
                    }
                }
                else
                {
                    disparorafaga = false;
                }
            }
            else if (movimientoarriba && movimientoabajo)
            {
                return;
            }
            
            else if (disparorafaga && movimientoarriba)
            {
                if (poder > 0)
                {
                    if (Math.Abs(tamaño) >= ancho)
                    {
                        poder -= 50;
                        tamaño = ancho;
                        do { contador -= 1; } while (contador > 0);
                        disparorafaga = false;
                        tamaño = distancia;
                    }
                    else
                    {
                        tamaño += velocidad;
                    }
                }
                else
                {
                    disparorafaga = false;
                }
            }
            else if (disparorafaga && movimientoabajo)
            {
                if (poder > 0)
                {
                    if (Math.Abs(tamaño) >= ancho)
                    {
                        poder -= 50;
                        tamaño = ancho;
                        do { contador -= 1; } while (contador > 0);
                        disparorafaga = false;
                        tamaño = distancia;
                    }
                    else
                    {
                        tamaño += velocidad;
                    }
                }
                else
                {
                    disparorafaga = false;
                }
            }
            else if (movimientoarriba)
            {
                if (y - desplazamiento >= 0)
                {
                    y -= desplazamiento;
                }
                else
                {
                    y = 0;
                }
            }
            else if (movimientoabajo)
            {
                if ((y + desplazamiento) <= alto - distancia)
                {
                    y += desplazamiento;
                }
                else
                {
                    y = alto - distancia;
                }
            }
            else if (disparorafaga)
            {
                if (poder > 0)
                {
                        if (Math.Abs(tamaño) >= ancho)
                        {
                            poder -= 50;
                            tamaño = ancho;
                            do { contador -= 1; } while (contador > 0);
                            disparorafaga = false;
                            tamaño = distancia;
                        }
                        else
                        {
                            tamaño += velocidad;
                        }
                }
                else
                {
                    disparorafaga = false;
                }
            }
        }
        public void ActualizarTecla(Keys key, bool down)
        {
            if (key == teclaarriba)
            {
                movimientoarriba = down;
            }
            else if (key == teclaabajo)
            {
                movimientoabajo = down;
            }
        }
        public void ActualizarTeclaD(Keys key, bool down)
        {
            if (key == tecladisparo)
            {
                if (tamaño == distancia)
                    disparorafaga = down;
            }
            
        }

        public void Dibujar(PaintEventArgs e, double altura)
        {
            this.altura = altura;
            if (disparorafaga)
            {
                e.Graphics.DrawImage(i, (int)(x), (int)(y), (int)(sentido * tamaño), (int)(altura));
            }
        }
        public void InflingirDaño()
        {
            dañoneto += daño;
        }
        public void GetPoder(double poder)
        {
            this.poder = poder;
        }
        public void GetTamaño(double tamañocambiado)
        {
            this.tamañocambiado = tamañocambiado;
        }
        public Rectangle GetRectangle()
        {
            return new Rectangle((int)(x), (int)(y), (int)(tamañocambiado), (int)(altura));
        }

    }
}
