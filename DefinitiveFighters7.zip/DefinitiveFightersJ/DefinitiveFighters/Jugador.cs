﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DefinitiveFighters
{
    class Jugador
    {
        public double distancia;

        public double ancho;
        public double alto;

        //public double salud;
        //public double desplazamiento;
        //public bool estado;

        public double x;
        public double y;
        
        public bool movimientoarriba = false;
        public bool movimientoabajo = false;
        public bool disparorafaga = false;
        public bool aumentopoder = false;

        Keys teclaarriba;
        Keys teclaabajo;
        Keys teclarafaga;
        Keys teclapoder;

        public Image i;

        private double rx;
        private double ry;

        public double vida;
        public double poder;
        private double tamaño;
        private double dañonetorafaga;
        private double dañonetobola;

        public Jugador()
        {
            
        }
        public Jugador(double poder, double vida,double distancia, double ancho, double alto, Image i, double x, double y, Keys teclaarriba, Keys teclaabajo, Keys teclarafaga, Keys teclapoder)
        {
            this.poder = poder;
            this.vida = vida;
            this.teclaarriba = teclaarriba;
            this.teclaabajo = teclaabajo;
            this.teclarafaga = teclarafaga;
            this.teclapoder = teclapoder;
            this.x = x;
            this.y = y;
            this.distancia = distancia;
            this.ancho = ancho;
            this.alto = alto;

            this.i = i;
        }

        public void Mover(double desplazamiento)
        {
            if (movimientoabajo && movimientoarriba && disparorafaga)
            {
                y = ry;
                return;
            }
            if (movimientoarriba && disparorafaga)
            {
                y = ry;
                return;
            }
            if (movimientoabajo && disparorafaga)
            {
                y = ry;
                return;
            }
            else if (movimientoarriba && movimientoabajo)
            {
                y = ry;
                return;
            }
            else if (movimientoarriba)
            {
                y = ry;
                return;
            }
            else if (movimientoabajo)
            {
                y = ry;
                return;
            }
        }
        public void ActualizarTecla(Keys key, bool down)
        {
            if (key == teclaarriba)
            {
                movimientoarriba = down;
            }
            else if (key == teclaabajo)
            {
                movimientoabajo = down;
            }
            else if (key == teclapoder)
            {
                aumentopoder = down;
            }
        }

        public void ActualizarTeclaDisparador(Keys key, bool down)
        {
            if (key == teclarafaga)
            {
                disparorafaga = down;
            }
        }
        public void Dibujar(PaintEventArgs e)
        {
            e.Graphics.DrawImage(i, (int)(x), (int)(y), (int)(distancia), (int)(distancia));
        }
        public void ReducirPoder(double contador)
        {
            if (disparorafaga)
            {
                if (tamaño == distancia)
                {
                    if (poder - 99 <= 0)
                    {
                        {
                            poder = 0;
                            disparorafaga = false;
                        }
                    }
                    else if (poder - 99 > 0)
                    {
                        poder -= 99;
                        disparorafaga = false;
                    }
                }
            }
            else
            {
                disparorafaga = false;
            }
        }
        public void AumentarPoder()
        {
            if (aumentopoder)
            {
                if (poder < 100)
                {
                    poder += 1;
                }
            }
        }
        public void RecibirDaño()
        {
            vida = 100 - dañonetorafaga - dañonetobola;
        }
        public void GetCoordenadasRafaga(double rx, double ry)
        {
            this.rx = rx;
            this.ry = ry;
        }
        public void GetTamañoRafaga(double tamaño)
        {
            this.tamaño = tamaño;
        }
        public void GetDañoNeto(double dañonetorafaga, double dañonetobola)
        {
            this.dañonetorafaga = dañonetorafaga;
            this.dañonetobola = dañonetobola;
        }
        public Rectangle GetRectangle()
        {
            return new Rectangle((int)(x), (int)(y), (int)(distancia), (int)(distancia));
        }
    }
}


