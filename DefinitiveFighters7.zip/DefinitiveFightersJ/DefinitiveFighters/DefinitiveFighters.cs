﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DefinitiveFighters
{
    public partial class DefinitiveFighters : Form
    {
        private System.Timers.Timer timer;
        
        private Jugador p1;
        private Jugador p2;
        
        private BolaDeEnergia b1;
        private BolaDeEnergia b2;
        
        private RafagaDeEnergia r1;
        private RafagaDeEnergia r2;
        
        public double distancia = 100;
        public double desplazamiento = 10;
        public double poder = 100;
        public double vida = 100;
        public DefinitiveFighters()
        {
            InitializeComponent();
            p1 = new Jugador(poder, vida, distancia, Escenario.Width, Escenario.Height, Image.FromFile(@"..\..\img\GokuPJ.png"), (distancia), ((Escenario.Height / 2) - (distancia / 2)), Keys.W, Keys.S, Keys.C, Keys.X);
            p2 = new Jugador(poder, vida, distancia, Escenario.Width, Escenario.Height, Image.FromFile(@"..\..\img\Freezer.png"), (Escenario.Width - 2 * distancia), (Escenario.Height / 2 - distancia / 2), Keys.Up, Keys.Down, Keys.M, Keys.N);
            
            b1 = new BolaDeEnergia(Escenario.Width, Escenario.Height, distancia / 2, desplazamiento * 2, 1, 1, Image.FromFile(@"..\..\img\Bola.png"), distancia * 2, p1.y + distancia / 4, Keys.W, Keys.S, Keys.Z);
            b2 = new BolaDeEnergia(Escenario.Width, Escenario.Height, distancia / 2, desplazamiento * 2, -1, 1, Image.FromFile(@"..\..\img\Bola.png"), Escenario.Width - (2*distancia)-(distancia/2), p2.y + distancia / 4, Keys.Up, Keys.Down, Keys.B);

            r1 = new RafagaDeEnergia(distancia, Escenario.Width, Escenario.Height, distancia, desplazamiento * 3, 1, 1, Image.FromFile(@"..\..\img\RafagaGoku.png"), distancia * 2, p1.y, Keys.W, Keys.S, Keys.C);
            r2 = new RafagaDeEnergia(distancia, Escenario.Width, Escenario.Height, distancia, desplazamiento * 3, -1, 1, Image.FromFile(@"..\..\img\RafagaFreezer.png"), Escenario.Width - (2 * distancia), p2.y, Keys.Up, Keys.Down, Keys.M);

            Escenario.BackgroundImage = Image.FromFile(@"..\..\img\Namek.png");
            timer = new System.Timers.Timer();
            timer.Interval = 10;

            timer.Elapsed += OnTimedEvent; 
            timer.Enabled = true;
            this.Focus();
        }
        private void OnTimedEvent(Object source, System.Timers.ElapsedEventArgs e)
        {
            if (p1.vida>0 & p2.vida>0)
            {
                p1.GetCoordenadasRafaga(r1.x, r1.y);
                p2.GetCoordenadasRafaga(r2.x, r2.y);

                b1.GetCoordenadasJugador(p1.x, p1.y);
                b2.GetCoordenadasJugador(p2.x, p2.y);

                p1.GetTamañoRafaga(r1.tamaño);
                p2.GetTamañoRafaga(r2.tamaño);

                r1.GetTamaño(r1.tamaño);
                r2.GetTamaño(r2.tamaño);

                p1.GetDañoNeto(r2.dañoneto, b2.dañoneto);
                p2.GetDañoNeto(r1.dañoneto, b1.dañoneto);

                p1.RecibirDaño();
                p2.RecibirDaño();

                p1.ReducirPoder(1);
                p2.ReducirPoder(1);

                p1.AumentarPoder();
                p2.AumentarPoder();

                r1.GetPoder(p1.poder);
                r2.GetPoder(p2.poder);

                p1.Mover(10);
                p2.Mover(10);

                r1.Desplazar(10, 1);
                r2.Desplazar(10, 1);

                if (r1.GetRectangle().IntersectsWith(p2.GetRectangle()))
                {
                    Console.WriteLine("aa");
                    r1.InflingirDaño();
                }
                if (r2.GetRectangle().IntersectsWith(p1.GetRectangle()))
                {
                    Console.WriteLine("DD");
                    r2.InflingirDaño();
                }
                if (b1.GetRectangle().IntersectsWith(p2.GetRectangle()))
                {
                    b1.InflingirDaño();
                }
                if (b2.GetRectangle().IntersectsWith(p1.GetRectangle()))
                {
                    b2.InflingirDaño();
                }
                b1.Desplazar(10, Escenario.Width, b1.x >= Escenario.Width);
                b2.Desplazar(10, 0, b2.x <= 0);

                Escenario.Invalidate();
            }
            else
            {
                timer.Enabled = false;
            }
        }
        private void DefinitiveFighters_KeyDown(object sender, KeyEventArgs e)
        {
            p1.ActualizarTecla(e.KeyCode, true);
            p2.ActualizarTecla(e.KeyCode, true);
            p1.ActualizarTeclaDisparador(e.KeyCode, true);
            p2.ActualizarTeclaDisparador(e.KeyCode, true);
            b1.ActualizarTecla(e.KeyCode, true);
            b2.ActualizarTecla(e.KeyCode, true);
            r1.ActualizarTecla(e.KeyCode, true);
            r2.ActualizarTecla(e.KeyCode, true);
        }

        private void DefinitiveFighters_KeyUp(object sender, KeyEventArgs e)
        {
            p1.ActualizarTecla(e.KeyCode, false);
            p2.ActualizarTecla(e.KeyCode, false);
            b1.ActualizarTecla(e.KeyCode, false);
            b2.ActualizarTecla(e.KeyCode, false);
            b1.ActualizarTeclaD(e.KeyCode, true, 2*distancia , p1.y + distancia/4);
            b2.ActualizarTeclaD(e.KeyCode, true, Escenario.Width - (2 * distancia) - (distancia / 2), p2.y + distancia/4);
            r1.ActualizarTecla(e.KeyCode, false);
            r2.ActualizarTecla(e.KeyCode, false);
            r1.ActualizarTeclaD(e.KeyCode, true);
            r2.ActualizarTeclaD(e.KeyCode, true);
        }
        private void Escenario_Paint(object sender, PaintEventArgs e)
        {
            p1.Dibujar(e);
            p2.Dibujar(e);
            b1.Dibujar(e);
            b2.Dibujar(e);
            r1.Dibujar(e, distancia);
            r2.Dibujar(e, distancia);
            VidaJugador1.Text = String.Format("Vida: {0}", p1.vida);
            PoderJugador1.Text = String.Format("Poder: {0}", p1.poder);
            VidaJugador2.Text = String.Format("Vida: {0}", p2.vida);
            PoderJugador2.Text = String.Format("Poder: {0}", p2.poder);
            if (p1.vida <= 0)
            {
                IndicadorGanador.Text = String.Format("Felicidades Jugador 2, eres el ganador");
            }
            else if (p2.vida <= 0)
            {
                IndicadorGanador.Text = String.Format("Felicidades Jugador 1, eres el ganador");
            }
        }

        private void DefinitiveFighters_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void DefinitiveFighters_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
