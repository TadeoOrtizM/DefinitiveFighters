﻿namespace DefinitiveFighters
{
    partial class DefinitiveFighters
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Escenario = new System.Windows.Forms.PictureBox();
            this.VidaJugador1 = new System.Windows.Forms.Label();
            this.PoderJugador1 = new System.Windows.Forms.Label();
            this.VidaJugador2 = new System.Windows.Forms.Label();
            this.PoderJugador2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.IndicadorGanador = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Escenario)).BeginInit();
            this.SuspendLayout();
            // 
            // Escenario
            // 
            this.Escenario.BackColor = System.Drawing.Color.White;
            this.Escenario.Location = new System.Drawing.Point(10, 12);
            this.Escenario.Name = "Escenario";
            this.Escenario.Size = new System.Drawing.Size(1280, 720);
            this.Escenario.TabIndex = 0;
            this.Escenario.TabStop = false;
            this.Escenario.Paint += new System.Windows.Forms.PaintEventHandler(this.Escenario_Paint);
            // 
            // VidaJugador1
            // 
            this.VidaJugador1.AutoSize = true;
            this.VidaJugador1.Location = new System.Drawing.Point(124, 757);
            this.VidaJugador1.Name = "VidaJugador1";
            this.VidaJugador1.Size = new System.Drawing.Size(36, 17);
            this.VidaJugador1.TabIndex = 1;
            this.VidaJugador1.Text = "Vida\r\n";
            // 
            // PoderJugador1
            // 
            this.PoderJugador1.AutoSize = true;
            this.PoderJugador1.Location = new System.Drawing.Point(209, 757);
            this.PoderJugador1.Name = "PoderJugador1";
            this.PoderJugador1.Size = new System.Drawing.Size(46, 17);
            this.PoderJugador1.TabIndex = 2;
            this.PoderJugador1.Text = "Poder";
            // 
            // VidaJugador2
            // 
            this.VidaJugador2.AutoSize = true;
            this.VidaJugador2.Location = new System.Drawing.Point(1018, 757);
            this.VidaJugador2.Name = "VidaJugador2";
            this.VidaJugador2.Size = new System.Drawing.Size(36, 17);
            this.VidaJugador2.TabIndex = 3;
            this.VidaJugador2.Text = "Vida";
            // 
            // PoderJugador2
            // 
            this.PoderJugador2.AutoSize = true;
            this.PoderJugador2.Location = new System.Drawing.Point(1111, 757);
            this.PoderJugador2.Name = "PoderJugador2";
            this.PoderJugador2.Size = new System.Drawing.Size(46, 17);
            this.PoderJugador2.TabIndex = 4;
            this.PoderJugador2.Text = "Poder";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(168, 735);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Jugador 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1062, 735);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Jugador 2";
            // 
            // IndicadorGanador
            // 
            this.IndicadorGanador.AutoSize = true;
            this.IndicadorGanador.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IndicadorGanador.Location = new System.Drawing.Point(221, 656);
            this.IndicadorGanador.Name = "IndicadorGanador";
            this.IndicadorGanador.Size = new System.Drawing.Size(0, 52);
            this.IndicadorGanador.TabIndex = 7;
            this.IndicadorGanador.Click += new System.EventHandler(this.label3_Click);
            // 
            // DefinitiveFighters
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1302, 783);
            this.Controls.Add(this.IndicadorGanador);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PoderJugador2);
            this.Controls.Add(this.VidaJugador2);
            this.Controls.Add(this.PoderJugador1);
            this.Controls.Add(this.VidaJugador1);
            this.Controls.Add(this.Escenario);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "DefinitiveFighters";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.DefinitiveFighters_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DefinitiveFighters_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DefinitiveFighters_KeyPress);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.DefinitiveFighters_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.Escenario)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox Escenario;
        public System.Windows.Forms.Label VidaJugador1;
        private System.Windows.Forms.Label PoderJugador1;
        private System.Windows.Forms.Label VidaJugador2;
        private System.Windows.Forms.Label PoderJugador2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label IndicadorGanador;
    }
}

