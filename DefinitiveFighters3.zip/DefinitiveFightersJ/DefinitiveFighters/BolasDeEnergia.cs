﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefinitiveFighters
{
    class BolasDeEnergia
    {
        private BolaDeEnergia[] bolas;

        public BolasDeEnergia(int n, double tamaño, double velocidad, double sentido, double daño, Image i, double x, double y)
        {
            bolas = new BolaDeEnergia[n];

      //      for (int c = 0; c < n; c++)
             //   bolas[c] = new BolaDeEnergia(tamaño, velocidad, sentido, daño, i, x, y);
        }
        public void Dibujar(Graphics graphics)
        {
       //     for (int i = 0; i < bolas.Length; i++)
               // bolas[i].Dibujar(graphics);
        }
    }
}
