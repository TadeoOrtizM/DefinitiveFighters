﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DefinitiveFighters
{
    class BolaDeEnergia
    {
        public double velocidad;
        public double daño;
        public Image i;
        public double sentido;
        public double tamaño;

        public double x;
        public double y;

        public double ancho;
        public double alto;

        private bool disparobola;

        Keys tecladisparo;
        Keys teclaarriba;
        Keys teclaabajo;

        private bool movimientoarriba;
        private bool movimientoabajo;

        public BolaDeEnergia(double ancho, double alto, double tamaño, double velocidad, double sentido, double daño, Image i, double x, double y, Keys teclaarriba, Keys teclaabajo, Keys tecladisparo)
        {
            this.velocidad = velocidad;
            this.tamaño = tamaño;
            this.sentido = sentido;
            this.daño = daño;
            this.i = i;
            this.x = x;
            this.y = y;
            this.ancho = ancho;
            this.alto = alto;
            this.teclaabajo = teclaabajo;
            this.teclaarriba = teclaarriba;
            this.tecladisparo = tecladisparo;
        }
        public void Desplazar(double desplazamiento, double xo)
        {
            if (disparobola)
            {
                {
                    if (x >= ancho)
                    {
                        x = ancho;
                        return;
                    }
                    else
                    {
                        x += velocidad;
                    }
                    return;
                }
            }
            else 
                if (movimientoarriba && movimientoabajo)
                {
                    return;
                }
                else if (movimientoarriba)
                {
                    if (y - desplazamiento >= tamaño/2)
                    {
                        y -= desplazamiento;
                    }
                    else
                    {
                        y = tamaño/2;
                    }
                }
                else if (movimientoabajo)
                {
                    if ((y + desplazamiento) <= alto - (tamaño + tamaño/2))
                    {
                        y += desplazamiento;
                    }
                    else
                    {
                        y = alto - (tamaño + tamaño/2);
                    }
                }

        }
        public void ActualizarTecla(Keys key, bool down)
        {
            if (key == teclaarriba)
            {
                movimientoarriba = down;
            }
            else if (key == teclaabajo)
            {
                movimientoabajo = down;
            }
        }
        public void ActualizarTeclaD(Keys key, bool down)
        {
            if (key == tecladisparo)
            {
                disparobola = down;
            }
        }

        public void Dibujar(PaintEventArgs e)
        {
            if (disparobola)
            {
                e.Graphics.DrawImage(i, (int)(x), (int)(y), (int)(tamaño), (int)(tamaño));
            }
        }
    }
}
