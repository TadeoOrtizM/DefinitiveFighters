﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DefinitiveFighters
{
    public partial class DefinitiveFighters : Form
    {
        private System.Timers.Timer timer;
        private Jugador p1;
        private Jugador p2;
        private BolaDeEnergia b1;
        public double distancia = 100;
        public double desplazamiento = 10;
        public double contadordebolas = 0;
        public DefinitiveFighters()
        {
            InitializeComponent();
            p1 = new Jugador(distancia, Escenario.Width, Escenario.Height, Image.FromFile(@"..\..\img\GokuPJ.png"), (distancia), ((Escenario.Height / 2) - (distancia / 2)), Keys.W, Keys.S);
            p2 = new Jugador(distancia, Escenario.Width, Escenario.Height, Image.FromFile(@"..\..\img\Freezer.png"), (Escenario.Width - 2 * distancia), (Escenario.Height / 2 - distancia / 2), Keys.Up, Keys.Down);
            b1 = new BolaDeEnergia(Escenario.Width, Escenario.Height, distancia / 2, desplazamiento * 2, 1, 5, Image.FromFile(@"..\..\img\Bola.png"), distancia * 2, p1.y + distancia / 4, Keys.W, Keys.S, Keys.Z);
            Escenario.BackgroundImage = Image.FromFile(@"..\..\img\Namek.png");
            timer = new System.Timers.Timer();
            timer.Interval = 10;

            timer.Elapsed += OnTimedEvent; 
            timer.Enabled = true;
            this.Focus();
        }
        private void OnTimedEvent(Object source, System.Timers.ElapsedEventArgs e)
        {
            p1.Mover(10);
            p2.Mover(10);
            b1.Desplazar(10, 2*distancia);
            Escenario.Invalidate();
        }
        private void DefinitiveFighters_KeyDown(object sender, KeyEventArgs e)
        {
            p1.ActualizarTecla(e.KeyCode, true);  
            p2.ActualizarTecla(e.KeyCode, true);
            b1.ActualizarTeclaD(e.KeyCode, true);
            b1.ActualizarTecla(e.KeyCode, true);

        }

        private void DefinitiveFighters_KeyUp(object sender, KeyEventArgs e)
        {
            p1.ActualizarTecla(e.KeyCode, false);
            p2.ActualizarTecla(e.KeyCode, false);
            b1.ActualizarTecla(e.KeyCode, false);
        }
        private void Escenario_Paint(object sender, PaintEventArgs e)
        {
            p1.Dibujar(e);
            b1.Dibujar(e);
            p2.Dibujar(e);
        }
        private void Escenario_Click(object sender, EventArgs e)
        {

        }

        private void DefinitiveFighters_Load(object sender, EventArgs e)
        {

        }

        private void DefinitiveFighters_KeyPress(object sender, KeyPressEventArgs e)
        {

        }
    }
}
