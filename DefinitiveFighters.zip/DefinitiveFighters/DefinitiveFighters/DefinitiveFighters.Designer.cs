﻿namespace DefinitiveFighters
{
    partial class DefinitiveFighters
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Escenario = new System.Windows.Forms.PictureBox();
            this.BotonSalir = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Escenario)).BeginInit();
            this.SuspendLayout();
            // 
            // Escenario
            // 
            this.Escenario.BackColor = System.Drawing.Color.White;
            this.Escenario.Location = new System.Drawing.Point(10, 12);
            this.Escenario.Name = "Escenario";
            this.Escenario.Size = new System.Drawing.Size(1280, 720);
            this.Escenario.TabIndex = 0;
            this.Escenario.TabStop = false;
            this.Escenario.Paint += new System.Windows.Forms.PaintEventHandler(this.Escenario_Paint);
            // 
            // BotonSalir
            // 
            this.BotonSalir.Location = new System.Drawing.Point(1190, 741);
            this.BotonSalir.Name = "BotonSalir";
            this.BotonSalir.Size = new System.Drawing.Size(100, 30);
            this.BotonSalir.TabIndex = 1;
            this.BotonSalir.Text = "Salir";
            this.BotonSalir.UseVisualStyleBackColor = true;
            this.BotonSalir.Click += new System.EventHandler(this.BotonSalir_Click);
            // 
            // DefinitiveFighters
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1302, 783);
            this.Controls.Add(this.BotonSalir);
            this.Controls.Add(this.Escenario);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "DefinitiveFighters";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.Escenario)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox Escenario;
        private System.Windows.Forms.Button BotonSalir;
    }
}

