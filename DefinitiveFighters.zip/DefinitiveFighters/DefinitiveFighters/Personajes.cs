﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefinitiveFighters
{
    class Personajes
    {
        public double distancia;

        public double ancho;
        public double alto;

        private double salud;
        private double desplazamiento;
        public bool estado;

        public Image i;

        public Personajes()
        {
            distancia = 100;
            
            ancho = 1280;
            alto = 720;

            salud = 100;
            desplazamiento = 2;
            estado = false;
        }

        public void RecibirDaño()
        {

        }
    }
}
