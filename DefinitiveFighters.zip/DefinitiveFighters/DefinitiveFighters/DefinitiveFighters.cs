﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DefinitiveFighters
{
    public partial class DefinitiveFighters : Form
    {
        private Personajes p;
        private PersonajeJugador j;
        public DefinitiveFighters()
        {
            InitializeComponent();
            p = new PersonajeJugador(Escenario.Width, Escenario.Height);
            Escenario.BackgroundImage = Image.FromFile(@"..\..\img\FondoEscenario.png");
        }

        private void BotonSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Escenario_Paint(object sender, PaintEventArgs e)
        {
            j.Dibujar(e.Graphics);
        }
    }
}
