﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefinitiveFighters
{
    class PersonajeJugador : Personajes
    {
        public double x;
        public double y;

        public PersonajeJugador(double ancho, double alto)
        {
            this.ancho = ancho;
            this.ancho = ancho;

            this.x = distancia;
            this.y = alto / 2;

            i = Image.FromFile(@"..\..\img\GokuPJ.png");
        }

        public void Mover(double desplazamiento)
        {
            y += desplazamiento;
        }
        public void CambiaEstado()
        {
            estado = !estado;
        }

        public bool GetEstado()
        {
            return estado;
        }

        public void Dibujar(Graphics graphics)
        {
            graphics.DrawImage(i, (int)(x), (int)(y), (int)(distancia), (int)(distancia));
        }
    }
}
